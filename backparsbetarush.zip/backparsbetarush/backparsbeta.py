import requests
import csv
import time
import os

def parse_leaderboard(url, filename, json_key, csv_header):
    """
    Делает GET-запросы (limit=101) по страницам с offset,
    собирает все записи и сохраняет в CSV:
      - Первая колонка: userAlias
      - Вторая колонка: csv_header (значение берем из row[json_key]).
    """
    offset = 0
    limit = 101
    all_rows = []

    while True:
        # Параметры limit/offset передаем через params,
        # остальные (?range=...&excludeMms=...) уже зашиты в url
        params = {
            "limit": limit,
            "offset": offset
        }
        print(f"Запрос offset={offset} → {url}")
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()  # Выбросит исключение, если HTTP != 200

        data_json = resp.json()
        if not isinstance(data_json, list):
            print("Ответ не массив (list). Останавливаемся.")
            break

        count_received = len(data_json)
        if count_received == 0:
            print("0 записей. Заканчиваем.")
            break

        all_rows.extend(data_json)
        print(f"Получено {count_received} записей. Всего: {len(all_rows)}.")

        if count_received < limit:
            print("Достигнут конец выборки. Останавливаемся.")
            break

        offset += limit
        time.sleep(1)

    if all_rows:
        # Сохраняем в CSV рядом со скриптом
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(script_dir, filename)

        with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            # Первая строка: userAlias, csv_header
            writer.writerow(["userAlias", csv_header])
            for row in all_rows:
                user_alias = row.get("userAlias", "")
                val = row.get(json_key, "")  # В JSON ключ называется json_key
                writer.writerow([user_alias, val])

        print(f"Сохранено {len(all_rows)} строк в '{output_path}'\n")
    else:
        print("Нет данных для сохранения.\n")


def main():
    # 1. Узнаём, какой день надо парсить (например TwentySeven, TwentyEight и т.д.)
    day_input = input("Введите название дня (например: TwentySeven, TwentyEight): ").strip()

    # 2. Формируем URL для Volume
    url_volume = (
        f"https://api.backpack.exchange/wapi/v1/statistics/volume/quote/USDC?"
        f"range=publicBetaTestCampaign{day_input}"
        f"&mode=both"
        f"&excludeMms=true"
    )
    # В итоговый CSV хотим userAlias и volume
    parse_leaderboard(
        url=url_volume,
        filename=f"day{day_input}_volume.csv",
        json_key="volume",     # Ключ в JSON
        csv_header="volume"    # Как подпишем колонку в CSV
    )

    # 3. Формируем URL для PnL
    url_pnl = (
        f"https://api.backpack.exchange/wapi/v1/statistics/pnl?"
        f"range=publicBetaTestCampaign{day_input}"
        f"&excludeMms=true"
    )
    # Сервер возвращает ту же структуру, где есть "volume" вместо "pnl"
    # Но мы хотим назвать колонку pnl
    parse_leaderboard(
        url=url_pnl,
        filename=f"day{day_input}_pnl.csv",
        json_key="volume",    # Ключ в JSON
        csv_header="pnl"      # Название колонки
    )

if __name__ == "__main__":
    main()
