import requests
import csv
import time
import os

def main():
    base_url = "https://api.backpack.exchange/wapi/v1/statistics/volume/quote/USDC"
    offset = 0
    limit = 101
    all_rows = []

    while True:
        params = {
            "range": "iOCampaignOne",  # Используем найденный параметр
            "mode": "both",
            "excludeMms": "true",
            "limit": limit,
            "offset": offset
        }
        print(f"Запрашиваем offset={offset} ...")
        resp = requests.get(base_url, params=params, timeout=30)
        resp.raise_for_status()

        data_json = resp.json()
        if not isinstance(data_json, list):
            print("Неверный формат ответа (не list). Останавливаемся.")
            break

        count_received = len(data_json)
        if count_received == 0:
            print("Пришло 0 записей. Значит, дальше пусто. Останавливаемся.")
            break

        all_rows.extend(data_json)
        print(f"Получено {count_received} записей. Всего уже: {len(all_rows)}.")

        if count_received < limit:
            print("Похоже, что дальше страниц нет. Останавливаемся.")
            break

        offset += limit
        time.sleep(1)

    if all_rows:
        # Сохраняем CSV в ту же папку, где находится файл кода
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(script_dir, "iO_trading.csv")
        with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(["userAlias", "volume"])
            for row in all_rows:
                user_alias = row.get("userAlias", "")
                volume     = row.get("volume", "")
                writer.writerow([user_alias, volume])
        print(f"Сохранено {len(all_rows)} строк в '{output_path}'")
    else:
        print("Нет данных для сохранения.")

if __name__ == "__main__":
    main()
