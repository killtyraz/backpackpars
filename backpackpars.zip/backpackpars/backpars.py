import time
import csv
import os

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup

def parse_current_table(driver):
    """
    Парсит текущую таблицу и возвращает список [rank, name, value].
    """
    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")
    
    tbody = soup.select_one("tbody.gap-2.divide-y.divide-baseBorderLight")
    rows_data = []
    if tbody:
        rows = tbody.find_all("tr", class_="hover:bg-baseBackgroundL2")
        for row in rows:
            tds = row.find_all("td")
            if len(tds) >= 3:
                rank = tds[0].get_text(strip=True)
                name = tds[1].get_text(strip=True)
                val  = tds[2].get_text(strip=True)  # например: $3,915,566.02
                rows_data.append([rank, name, val])
    return rows_data

def click_next_page(driver):
    """
    Кликает на кнопку "Next" по Xpath:
    //*[@id="__next"]/div/div[3]/div/div[2]/div/div[2]/div/div[2]/div[1]/div/button[2]
    Возвращает True, если клик выполнен, иначе False.
    """
    try:
        # Прокручиваем всю страницу вниз
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)
        
        # Xpath кнопки Next
        xpath_next = "//*[@id='__next']/div/div[3]/div/div[2]/div/div[2]/div/div[2]/div[1]/div/button[2]"
        wait = WebDriverWait(driver, 10)
        next_btn = wait.until(EC.element_to_be_clickable((By.XPATH, xpath_next)))
        
        # Скроллим непосредственно к кнопке, чтобы её точно было видно
        driver.execute_script("arguments[0].scrollIntoView(true);", next_btn)
        time.sleep(1)
        
        next_btn.click()
        time.sleep(3)  # Небольшая задержка, чтобы данные успели обновиться
        return True
    except Exception as e:
        print("    Не удалось кликнуть Next:", e)
        return False

def select_option(driver, wait, option_id_part):
    """
    Открывает выпадающее меню (aria-label='Dropdown menu'),
    затем кликает по опции, чей id содержит option_id_part (например 'option-volume-49').
    """
    dropdown_sel = "button[aria-label='Dropdown menu']"
    dropdown_btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, dropdown_sel)))
    dropdown_btn.click()
    time.sleep(1)
    
    # Ищем элемент c id, содержащим option_id_part (напр. option-volume-49)
    opt_sel = f"div[id*='{option_id_part}']"
    opt_btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, opt_sel)))
    opt_btn.click()
    time.sleep(3)  # Ждём, пока таблица обновится

def parse_leaderboard(driver, wait, option_id_part, label, filename):
    import os
    
    print(f"\n=== Парсим {label} ===")
    select_option(driver, wait, option_id_part)
    
    all_rows = []
    for page_idx in range(1, 11):
        print(f"  Страница {page_idx} ({label})...")
        rows_data = parse_current_table(driver)
        print(f"    Найдено строк: {len(rows_data)}")
        if not rows_data:
            break
        all_rows.extend(rows_data)
        
        clicked = click_next_page(driver)
        if not clicked:
            print("    Кнопка Next недоступна или не найдена. Останавливаемся.")
            break
    
    if all_rows:
        # Формируем путь к файлу в той же папке, где лежит скрипт
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(script_dir, filename)
        
        print("Текущая рабочая директория:", script_dir)
        with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Rank", "Name", label])
            writer.writerows(all_rows)
        print(f"Сохранено {len(all_rows)} строк в '{output_path}'")
    else:
        print(f"Нет данных по {label}, файл '{filename}' не создан.")

    """
    - Переключается в нужную вкладку (например, IO Trading) с помощью select_option.
    - Парсит до 10 страниц (или пока кнопка 'Next' не станет недоступной).
    - Сохраняет результат в CSV-файл (filename).
    """
    print(f"\n=== Парсим {label} ===")
    select_option(driver, wait, option_id_part)
    
    all_rows = []
    for page_idx in range(1, 11):
        print(f"  Страница {page_idx} ({label})...")
        rows_data = parse_current_table(driver)
        print(f"    Найдено строк: {len(rows_data)}")
        if not rows_data:
            # Если вернулась пустая таблица, прекращаем
            break
        all_rows.extend(rows_data)
        
        # Пробуем кликнуть на Next
        clicked = click_next_page(driver)
        if not clicked:
            print("    Кнопка Next недоступна или не найдена. Останавливаемся.")
            break
    
    if all_rows:
        # Сохраняем данные в CSV
        print("Текущая рабочая директория:", os.getcwd())
        with open(filename, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Rank", "Name", label])
            writer.writerows(all_rows)
        print(f"Сохранено {len(all_rows)} строк в '{filename}'")
    else:
        print(f"Нет данных по {label}, файл '{filename}' не создан.")

def main():
    driver = webdriver.Chrome()
    driver.get("https://backpack.exchange/rewards/leaderboard")
    
    wait = WebDriverWait(driver, 30)
    time.sleep(5)  # Даём странице время на первичную подгрузку
    
    # Парсим лишь IO Trading Campaign (Vol)
    parse_leaderboard(driver, wait, "option-volume-49", "IO_Trading", "io_trading.csv")
    
    driver.quit()

if __name__ == "__main__":
    main()
